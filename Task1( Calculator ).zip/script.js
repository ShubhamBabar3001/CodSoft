
    const previous=0;
    let AnsVariable=0;
    function calculate(){
        const display = document.getElementById('dis');
        const value = display.value;
        const result = eval(value);
        display.value = `${value}=${result}`; 
        AnsVariable=result; 
    }
    function ansfun(){
        const display = document.getElementById('dis');
        checkInput(AnsVariable);
    }
    function checkInput(str){
        const display = document.getElementById('dis');
        value=display.value;
        if (value.includes('=')){
           display.value="";
        }
        display.value+=str;
    }
    function forAcButton(){
        const display = document.getElementById('dis');
        display.value="";
        AnsVariable=0;
    }
